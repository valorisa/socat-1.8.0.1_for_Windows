/* source: xio-creat.h */
/* Copyright Gerhard Rieger and contributors (see file CHANGES) */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xio_creat_h_included
#define __xio_creat_h_included 1

extern const struct addrdesc xioaddr_creat;

#endif /* !defined(__xio_creat_h_included) */
